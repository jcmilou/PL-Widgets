String.toLocaleString({
	"en": {
		"%profileT": "My profile",
		"%editT": "Edit",
		"%invite": "Invite Friends",
		"%find": "Find Friends",
		"%logout": "Log Out"
	},
		"en-US": {
			"%profileT": "My profile",
			"%editT": "Edit",
			"%invite": "Invite Friends",
			"%find": "Find Friends",
			"%logout": "Log Out"
		},
		"en-GB": {
			"%profileT": "My profile",
			"%editT": "Edit",
			"%invite": "Invite Friends",
			"%find": "Find Friends",
			"%logout": "Log Out"
		},
	"pt": {
		"%profileT": "Meu perfil",
		"%editT": "editar",
		"%invite": "Convide amigos",
		"%find": "Encontrar amigos",
		"%logout": "sair"
	},
	"es": {
		"%profileT": "Mi perfil",
		"%editT": "Editar",
		"%invite": "Invitar Amigos",
		"%find": "Encontrar Amigos",
		"%logout": "Salir"
	},
	"fr": {
		"%profileT": "Mon profil",
		"%editT": "modifier",
		"%invite": "Inviter Amis",
		"%find": "Trouver Amis",
		"%logout": "Déconnecter"
	},
	"de": {
		"%profileT": "Mein Profil",
		"%editT": "Bearbeiten",
		"%invite": "Freunde einladen",
		"%find": "Freunde finden",
		"%logout": "Ausloggen"
	},
	"it": {
		"%profileT": "Il mio profilo",
		"%editT": "Modifica",
		"%invite": "Invita amici",
		"%find": "Trova amici",
		"%logout": "Disconnettersi"
	}
});
