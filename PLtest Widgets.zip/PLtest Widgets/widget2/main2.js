(function() {

// Localize jQuery variable
var jQuery;

/******** Load jQuery if not present *********/
if (window.jQuery === undefined || window.jQuery.fn.jquery !== '2.1.3') {
    var script_tag = document.createElement('script');
    script_tag.setAttribute("type","text/javascript");
    script_tag.setAttribute("src",
        "http://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js");
    if (script_tag.readyState) {
      script_tag.onreadystatechange = function () { // For old versions of IE
          if (this.readyState == 'complete' || this.readyState == 'loaded') {
              scriptLoadHandler();
          }
      };
    } else {
      script_tag.onload = scriptLoadHandler;
    }
    // Try to find the head, otherwise default to the documentElement
    (document.getElementsByTagName("head")[0] || document.documentElement).appendChild(script_tag);
} else {
    // The jQuery version on the window is the one we want to use
    jQuery = window.jQuery;
    main();
}

/******** Called once jQuery has loaded ******/
function scriptLoadHandler() {
    // Restore $ and window.jQuery to their previous values and store the
    // new jQuery in our local jQuery variable
    jQuery = window.jQuery.noConflict(true);
    // Call our main function
    main(); 
}

/******** Main function ********/
function main() { 
    jQuery(document).ready(function($) { 
        /******* Load CSS *******/
        var css_link = $("<link>", { 
            rel: "stylesheet", 
            type: "text/css", 
            href: "style.css" 
        });
		var css_link2 = $("<link>", { 
            rel: "stylesheet",  
            href: "https://fonts.googleapis.com/icon?family=Material+Icons" 
        });
        css_link.appendTo('head');
		css_link2.appendTo('head');
		
  WebFontConfig = {
    google: { families: [ 'Open+Sans::latin' ] }
  };
  (function() {
    var wf = document.createElement('script');
    wf.src = 'https://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';
    wf.type = 'text/javascript';
    wf.async = 'true';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(wf, s);
  })();

	 $(document).ready(function() {	
	 //Get JSON data
               $.getJSON("data.json", function(wd) {
				   //format number to add commas
					function addCommas(nStr) {
						nStr += '';
						x = nStr.split('.');
						x1 = x[0];
						x2 = x.length > 1 ? '.' + x[1] : '';
						var rgx = /(\d+)(\d{3})/;
						while (rgx.test(x1)) {
								x1 = x1.replace(rgx, '$1' + ',' + '$2');
						}
						return x1 + x2;
					}
					wd.widgetprofile.infocount = addCommas(wd.widgetprofile.infocount);
					//Add content to the file
				  $("#widget-container").html("<div class='content'><div class='content-img'>" + wd.widgetprofile.smallimg + "</div><div class='content-info'><div class='name'>" + wd.widgetprofile.name + "</div><div class='info'>"+ wd.widgetprofile.infocount +" followers</div></div></div><div class='menu'><a href='#'><div class='edituser'><span>Edit user</span><i class='material-icons'>person</i></div></a><a href='#'><div class='stats'><span>Web statistics</span><i class='material-icons'>format_align_left</i></div></a><a href='#'><div class='upsettings'><span>Upload settings</span><i class='material-icons'>build</i></div></a><a href='#'><div class='events'><span>Events</span><i class='material-icons'>location_on</i></div></a></div>");
               });
            });
    });
}
})();