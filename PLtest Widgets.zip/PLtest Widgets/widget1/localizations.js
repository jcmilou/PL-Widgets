String.toLocaleString({
	"en": {
		"%info": "Your talent amazes! This is awesome. Excited to see the final product."
	},
		"en-US": {
			"%info": "Your talent amazes! This is awesome. Excited to see the final product.."
		},
		"en-GB": {
			"%info": "Your talent amazes! This is awesome. Excited to see the final product."
		},
	"pt": {
		"%info": "Seu talento surpreende ! Isso é incrível.  Animado para ver o produto final."
	},
	"es": {
		"%info": "Su talento sorprende ! Esto es increíble.  Emocionados de ver el producto final."
	},
	"fr": {
		"%info": "Votre talent étonne! C'est génial.  Excité de voir le produit final."
	},
	"de": {
		"%info": "Ihr Talent erstaunt ! Das ist fantastisch.  Excited das Endprodukt zu sehen."
	},
	"it": {
		"%info": "Il tuo talento stupisce ! Questo e spettacolare.  Eccitato per vedere il prodotto finale."
	}
});
